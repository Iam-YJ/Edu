package com.nhnacademy.edu.jdbc1.service.course;

public class Course {
}
