package com.nhnacademy.edu.jdbc1.repository;

import com.nhnacademy.edu.jdbc1.service.course.CourseRepository;
import org.springframework.stereotype.Component;

@Component
public class JdbcCourseRepository implements CourseRepository {
}
