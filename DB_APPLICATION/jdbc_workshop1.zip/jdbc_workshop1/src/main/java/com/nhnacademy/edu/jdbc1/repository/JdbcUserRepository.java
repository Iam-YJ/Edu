package com.nhnacademy.edu.jdbc1.repository;

import com.nhnacademy.edu.jdbc1.service.login.UserRepository;

public class JdbcUserRepository implements UserRepository {
}
