package com.nhnacademy.edu.jdbc1.service.course;

import org.springframework.stereotype.Service;

@Service
public class DefaultCourseCreationService implements CourseCreationService {
}
