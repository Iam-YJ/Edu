package com.nhnacademy.edu.jdbc1.service.login;

import org.springframework.stereotype.Service;

@Service
public class DefaultUserLoginService implements UserLoginService{
}
