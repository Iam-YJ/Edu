package com.nhnacademy.dispatcher.domain;

public class Item {
    private final Food food;
    private int amount;


    public Item(Food food, int amount) {
        this.food = food;
        this.amount = amount;
    }

    public Food getFood() {
        return food;
    }

    public int getAmount() {
        return amount;
    }

    public void decreaseAmount() throws AmountException {
        if (amount <= 0) {
            throw new AmountException("amount is less than or equal to zero");
        }

        amount--;
    }

    public void increaseAmount(int amount) {
        this.amount += amount;
    }

}
