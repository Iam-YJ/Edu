package com.nhnacademy.dispatcher.initializer;

import com.nhnacademy.dispatcher.domain.Food;
import com.nhnacademy.dispatcher.domain.FoodStand;
import java.util.Set;
import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.HandlesTypes;

@HandlesTypes({
    javax.servlet.Servlet.class,
    javax.servlet.Filter.class,
    javax.servlet.ServletContextListener.class
})
public class WebAppInitializer implements ServletContainerInitializer {
    @Override
    public void onStartup(Set<Class<?>> c, ServletContext ctx) throws ServletException {
        ctx.setInitParameter("counterFile", "counter.dat");
        ctx.setAttribute("lang", "ko");
        ctx.setAttribute("foodstand", constructFoodStand());
    }

    private FoodStand constructFoodStand() {
        FoodStand foodStand = new FoodStand();
        foodStand.add(new Food("onion", 1000), 2);
        foodStand.add(new Food("eggs", 2000), 5);
        foodStand.add(new Food("celery", 500), 10);
        foodStand.add(new Food("apple", 2000), 20);

        return foodStand;
    }

}
