package com.nhnacademy.dispatcher.command;

import com.nhnacademy.dispatcher.domain.AmountException;
import com.nhnacademy.dispatcher.domain.Cart;
import com.nhnacademy.dispatcher.domain.FoodStand;
import com.nhnacademy.dispatcher.domain.Item;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CartUpdateController implements Command {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        String[] items = request.getParameterValues("item");

        ServletContext servletContext = request.getServletContext();
        FoodStand foodStand = (FoodStand) servletContext.getAttribute("foodstand");

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        for(String itemName: items) {
            Item item = foodStand.getItem(itemName);

            try {
                item.decreaseAmount();
            } catch (AmountException ex) {
                request.setAttribute("exception", ex);
                throw new RuntimeException(ex);
            }

            cart.add(item.getFood(), 1);
        }

        return "/cart.jsp";
    }
}
