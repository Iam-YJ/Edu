package com.nhnacademy.dispatcher.domain;

public interface Counter {
    String COUNTER = "counter";
}
