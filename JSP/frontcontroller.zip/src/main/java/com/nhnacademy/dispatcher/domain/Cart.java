package com.nhnacademy.dispatcher.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Cart {
    private final Map<String, Item> items = new HashMap<>();

    public void add(Food food, int amount) {
        if (items.containsKey(food.getName())) {
            Item item = items.get(food.getName());
            item.increaseAmount(amount);
        } else {
            items.put(food.getName(), new Item(food, amount));
        }
    }

    public List<Item> getItems() {
        return new ArrayList<>(items.values());
    }

}
