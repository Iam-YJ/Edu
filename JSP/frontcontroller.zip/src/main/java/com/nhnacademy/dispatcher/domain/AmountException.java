package com.nhnacademy.dispatcher.domain;

public class AmountException extends Exception {
    public AmountException(String message) {
        super(message);
    }

}
