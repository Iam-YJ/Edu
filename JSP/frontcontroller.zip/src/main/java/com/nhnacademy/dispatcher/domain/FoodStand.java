package com.nhnacademy.dispatcher.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FoodStand {
    private final Map<String, Item> items = new HashMap<>();


    public void add(Food food, int amount) {
        items.put(food.getName(), new Item(food, amount));
    }

    public List<Item> getItems() {
        return new ArrayList<>(items.values());
    }

    public Item getItem(String name) {
        return items.get(name);
    }

}
