package com.nhnacademy.domain;

import lombok.NoArgsConstructor;
import lombok.Setter;
import org.jsoup.Jsoup;

import java.io.Serializable;

@NoArgsConstructor
@Setter
public class HtmlBeautifier implements Serializable {
    private String html;

    public String getHtml() {
        return Jsoup.parse(this.html).toString();
    }

}
