package com.nhnacademy.cookie;

import java.util.Set;
import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.HandlesTypes;

@HandlesTypes({
    javax.servlet.http.HttpServlet.class,
    javax.servlet.Filter.class,
    javax.servlet.ServletContextListener.class,
    javax.servlet.http.HttpSessionListener.class
})
public class WebAppInitializer implements ServletContainerInitializer {
    @Override
    public void onStartup(Set<Class<?>> set, ServletContext servletContext)
        throws ServletException {
        /*
                <context-param>
                    <param-name>url</param-name>
                    <param-value>https://nhnacademy.com/</param-value>
                </context-param>
         */
        servletContext.setInitParameter("url", "https://nhnacademy.com/");

        /*
                <context-param>
                    <param-name>counterFileName</param-name>
                    <param-value>counter.dat</param-value>
                </context-param>

         */
        servletContext.setInitParameter("counterFileName", "counter.dat");
    }

}
